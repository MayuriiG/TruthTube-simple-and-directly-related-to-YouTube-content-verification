import UIKit
import TruthTubeSDK

final class ViewController: UIViewController {

    private let titleTextField: UITextField = {
        let textField = UITextField()
        textField.placeholder = "Enter YouTube video title"
        textField.borderStyle = .roundedRect
        textField.translatesAutoresizingMaskIntoConstraints = false
        return textField
    }()

    private let analyzeButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("🤖 Analyze Video Title", for: .normal)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()

    private let resultLabel: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground

        view.addSubview(titleTextField)
        view.addSubview(analyzeButton)
        view.addSubview(resultLabel)

        analyzeButton.addTarget(
            self,
            action: #selector(analyzeTapped),
            for: .touchUpInside
        )

        NSLayoutConstraint.activate([
            titleTextField.topAnchor.constraint(
                equalTo: view.safeAreaLayoutGuide.topAnchor,
                constant: 40
            ),
            titleTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 24),
            titleTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -24),

            analyzeButton.topAnchor.constraint(equalTo: titleTextField.bottomAnchor, constant: 20),
            analyzeButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),

            resultLabel.topAnchor.constraint(equalTo: analyzeButton.bottomAnchor, constant: 30),
            resultLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 24),
            resultLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -24)
        ])
    }

    @objc private func analyzeTapped() {
        guard let title = titleTextField.text, !title.isEmpty else {
            resultLabel.text = "Please enter a video title."
            return
        }

        let result = TruthTubeAnalyzer.shared.analyze(title: title)
        resultLabel.text = result.formattedMessage
    }
}
