import XCTest
@testable import TruthTubeSDK

final class TruthTubeSDKTests: XCTestCase {
    func testFake() {
        XCTAssertEqual(
            TruthTubeAnalyzer.shared.analyze(title: "Deepfake exposed").riskLevel,
            .warning
        )
    }

    func testAI() {
        XCTAssertEqual(
            TruthTubeAnalyzer.shared.analyze(title: "AI generated video").riskLevel,
            .possibleAI
        )
    }

    func testClear() {
        XCTAssertEqual(
            TruthTubeAnalyzer.shared.analyze(title: "iOS Development Tutorial").riskLevel,
            .clear
        )
    }
}
