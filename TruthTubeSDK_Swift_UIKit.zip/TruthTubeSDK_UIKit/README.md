# TruthTubeSDK — Swift + UIKit

This version is for a standard Swift iOS project using UIKit. It does not require SwiftUI.

## Add to Xcode
1. Unzip this file.
2. Open your UIKit iOS project in Xcode.
3. File > Add Package Dependencies > Add Local.
4. Select the `TruthTubeSDK_UIKit` folder.
5. Add `TruthTubeSDK` to your app target.
6. Add `import TruthTubeSDK` to the Swift file where you want to use it.

## Swift usage

```swift
let result = TruthTubeAnalyzer.shared.analyze(title: "AI generated video")
print(result.formattedMessage)
```

See `UIKitExample/ViewController.swift` for a UIKit example using UIViewController, UITextField, UIButton, and UILabel.

Note: The SDK analyzes titles using the same keyword rules as the original browser extension. It does not automatically add a button inside the YouTube iPhone app.
